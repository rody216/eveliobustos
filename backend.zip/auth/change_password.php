<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(["error" => "No autorizado."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));
if (!isset($data->old_password) || !isset($data->new_password)) {
    http_response_code(400);
    echo json_encode(["error" => "Faltan campos."]);
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM admin WHERE username = 'evelio'");
$stmt->execute();
$user = $stmt->fetch();

if (!$user || !password_verify($data->old_password, $user['password'])) {
    http_response_code(403);
    echo json_encode(["error" => "Contraseña actual incorrecta."]);
    exit;
}

$new_hash = password_hash($data->new_password, PASSWORD_DEFAULT);
$update = $pdo->prepare("UPDATE admin SET password = ? WHERE username = 'evelio'");
$update->execute([$new_hash]);

echo json_encode(["success" => true]);
?>