<?php
// Admin login placeholder
?>