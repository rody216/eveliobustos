<?php
require_once '../config/db.php';

$quote = $_POST['quote'];
$author = $_POST['author'];
$avatar = '';

if (!empty($_FILES['avatar']['name'])) {
    $upload_dir = '../uploads/';
    $filename = basename($_FILES['avatar']['name']);
    $target_file = $upload_dir . time() . '_' . $filename;

    if (move_uploaded_file($_FILES['avatar']['tmp_name'], $target_file)) {
        $avatar = $target_file;
    }
}

$stmt = $pdo->prepare("INSERT INTO testimonios (quote, author, avatar) VALUES (?, ?, ?)");
$stmt->execute([$quote, $author, $avatar]);

echo json_encode(["success" => true]);
?>