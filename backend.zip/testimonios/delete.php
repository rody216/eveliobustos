<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['admin'])) {
    http_response_code(401);
    echo json_encode(["error" => "No autorizado."]);
    exit;
}

$data = json_decode(file_get_contents("php://input"));
$id = $data->id ?? null;

if ($id) {
    $stmt = $pdo->prepare("DELETE FROM testimonios WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(["success" => true]);
} else {
    http_response_code(400);
    echo json_encode(["error" => "ID no proporcionado."]);
}
?>