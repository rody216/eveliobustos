<?php
// Middleware placeholder
?>